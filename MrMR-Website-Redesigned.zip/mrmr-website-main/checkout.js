(async function(){
 const params=new URLSearchParams(location.search),id=params.get('product'),summary=document.getElementById('orderSummary'),form=document.getElementById('checkoutForm'),msg=document.getElementById('checkoutMessage'),button=document.getElementById('payButton'),emailInput=document.getElementById('customerEmail');
 let products=[];try{products=await(await fetch('products.json',{cache:'no-store'})).json()}catch(e){}
 const product=products.find(p=>p.id===id&&p.status==='published');
 if(!product){summary.textContent='Product unavailable';msg.textContent='This product is not currently available for purchase.';button.disabled=true;return}
 summary.innerHTML=`<div><strong>${product.name}</strong><div class="checkout-help">${product.format}</div></div><strong>₹${Number(product.price).toLocaleString('en-IN')}</strong>`;
 let config={ready:false};try{config=await(await fetch('/api/payment-config',{cache:'no-store'})).json()}catch(e){}
 if(config.ready){button.disabled=false;button.textContent=`Pay ₹${Number(product.price).toLocaleString('en-IN')} with Razorpay`;msg.textContent='Your payment will be verified by Mr.MR before download access is provided.'}
 else {button.disabled=true;button.textContent='Payment setup required';msg.textContent='Payments are not active yet. The site owner must configure Razorpay credentials, the Supabase order table, and private product storage before real purchases can be accepted.'}
 form.addEventListener('submit',async e=>{
  e.preventDefault();if(!config.ready||!product)return;
  if(!document.getElementById('termsAccepted').checked)return;
  button.disabled=true;button.textContent='Preparing secure checkout…';msg.className='notice';msg.textContent='Creating your order…';
  try{
   const create=await fetch('/api/create-order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({productId:product.id,email:emailInput.value.trim()})});const order=await create.json();if(!create.ok)throw new Error(order.error||'Unable to create order');
   if(!window.Razorpay)throw new Error('Razorpay Checkout did not load. Please refresh and try again.');
   const rz=new Razorpay({key:order.keyId,amount:order.amount,currency:order.currency,name:'Mr.MR',description:order.productName,order_id:order.orderId,prefill:{email:order.email},theme:{color:'#e8b94f'},modal:{ondismiss:()=>{button.disabled=false;button.textContent=`Pay ₹${Number(product.price).toLocaleString('en-IN')} with Razorpay`;msg.textContent='Checkout was closed. No confirmation was received; check your payment app before trying again.'}},handler:async response=>{
    msg.textContent='Verifying payment securely…';
    try{const vr=await fetch('/api/verify-payment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(response)});const result=await vr.json();if(!vr.ok||!result.verified)throw new Error(result.error||'Verification failed');if(result.downloadUrl){msg.className='notice success';msg.textContent='Payment verified. Your download is opening in a new tab.';const a=document.createElement('a');a.href=result.downloadUrl;a.target='_blank';a.rel='noopener';a.click();button.textContent='Download link opened';}else{msg.textContent=result.message||'Payment verified. Contact support with your payment reference for access.';button.textContent='Payment verified';}}
    catch(err){msg.className='notice error';msg.textContent=err.message+' If money was deducted, do not pay again; contact rachamantimani243@gmail.com with the payment reference.';button.disabled=false;button.textContent='Retry verification';}
   }});rz.on('payment.failed',r=>{msg.className='notice error';msg.textContent='Payment was not completed. You have not been given download access. You may retry after checking your payment app.';button.disabled=false;button.textContent=`Retry payment · ₹${Number(product.price).toLocaleString('en-IN')}`});rz.open();
  }catch(err){msg.className='notice error';msg.textContent=err.message;button.disabled=false;button.textContent=`Try again · ₹${Number(product.price).toLocaleString('en-IN')}`}
 });
})();
