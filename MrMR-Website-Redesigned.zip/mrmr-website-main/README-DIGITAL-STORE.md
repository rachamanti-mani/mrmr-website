# Mr.MR Digital Products — implementation notes

This update extends the existing static HTML/CSS/JavaScript project. It does not replace the existing website or Supabase inquiry/admin features.

## What's included
- `products.html` and `products.js`: focused digital product catalogue; only products marked `published` appear.
- `checkout.html` and `checkout.js`: checkout screen; remains disabled until server-side payment setup is detected.
- `api/payment-config.js`, `api/create-order.js`, `api/verify-payment.js`: Vercel serverless endpoints for Razorpay order creation, signature verification, captured-payment verification, order recording, and short-lived signed download links.
- `product-admin.html` and `product-admin.js`: admin product editor using Supabase auth/session and the `digital_products` table.
- `digital-products-setup.sql`: RLS, catalog/order schema, and initial product records.
- `refund-policy.html`, `privacy.html`, `terms.html`: draft policy pages that need final review before launch.
- `assets/manikanta-profile.jpeg`: supplied founder photo used on homepage and About page.

## Required setup before real sales
1. In Supabase SQL Editor, review and run `digital-products-setup.sql`.
2. Set the intended admin account's Supabase `app_metadata.role` to `admin` using a trusted server/admin process. Do not let users edit their own app metadata.
3. Create a **private** Supabase Storage bucket named `digital-products`.
4. Upload the finished files from the separate `MR-Digital-Products-Initial-Pack.zip` to that bucket using the exact filenames listed in `products.json` / the SQL seed. Do not put paid downloadable files in the public website directory.
5. In Vercel project settings, configure environment variables from `.env.example`: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`. Keep secrets server-side only. Start with Razorpay test credentials.
6. Deploy to Vercel. The `/api` directory is intended for Vercel Node serverless functions.
7. Test order creation, failed/cancelled payments, captured payment verification, order storage, private signed download access, duplicate/retry scenarios, and support handling using test mode. Do not announce live purchasing until tests pass.
8. Finalize the privacy, terms, and refund policy for the actual implementation and applicable Indian requirements.
9. Switch to live Razorpay credentials only after account activation, verification, and end-to-end tests.

## Product management
The public store prefers `digital_products` records from Supabase and falls back to `products.json`. Product administration updates the database catalog, including price and status. The serverless payment endpoint reads the current published product and price from Supabase so a price edit does not require code changes. New product IDs must still be added to the trusted payment/delivery configuration or a server-side allowlist before sale; do not accept arbitrary storage paths from the browser.

## Important implementation notes
- Supabase publishable key is safe for browser use only with correct RLS policies. Never put service-role keys in frontend files.
- The order table intentionally has no public RLS policies; only server-side service-role functions should read/write orders.
- Download links expire after 10 minutes. A paid order can be verified again by support/admin tooling if the user loses the link; this current first version does not yet include a customer self-service order lookup page.
- Email delivery of receipts/download links is not configured in this version; customers can use the short-lived download link shown after successful verification and contact support for recovery. Add an email provider before claiming automated email delivery.
- Existing admin CRM and inquiry flows are preserved. The new product manager requires the existing Supabase admin session and the role policy described above.
