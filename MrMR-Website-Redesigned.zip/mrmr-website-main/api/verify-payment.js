const crypto = require('crypto');
module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
  const {RAZORPAY_KEY_ID:keyId,RAZORPAY_KEY_SECRET:secret,SUPABASE_URL:url,SUPABASE_SERVICE_ROLE_KEY:serviceKey}=process.env;
  if(!keyId||!secret||!url||!serviceKey)return res.status(503).json({error:'Payment verification is not configured.'});
  const {razorpay_order_id:orderId,razorpay_payment_id:paymentId,razorpay_signature:signature}=req.body||{};
  if(!orderId||!paymentId||!signature)return res.status(400).json({error:'Payment details are incomplete.'});
  const expected=crypto.createHmac('sha256',secret).update(`${orderId}|${paymentId}`).digest('hex');
  const a=Buffer.from(expected); const b=Buffer.from(String(signature));
  if(a.length!==b.length||!crypto.timingSafeEqual(a,b))return res.status(400).json({error:'Payment signature could not be verified.'});
  try{
    const headers={apikey:serviceKey,Authorization:`Bearer ${serviceKey}`};
    const lookup=await fetch(`${url}/rest/v1/digital_orders?razorpay_order_id=eq.${encodeURIComponent(orderId)}&select=id,product_id,customer_email,amount_paise,payment_status,razorpay_payment_id`,{headers});
    const rows=await lookup.json(); const order=rows?.[0];
    if(!lookup.ok||!order)return res.status(404).json({error:'Order record was not found.'});
    if(order.payment_status==='paid' && order.razorpay_payment_id !== paymentId)return res.status(409).json({error:'This order has already been paid with a different payment reference. Contact support if you need help.'});
    const paymentRes=await fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(paymentId)}`,{headers:{'Authorization':'Basic '+Buffer.from(keyId+':'+secret).toString('base64')}});
    const payment=await paymentRes.json();
    if(!paymentRes.ok||payment.order_id!==orderId||payment.status!=='captured'||payment.amount!==order.amount_paise||payment.currency!=='INR')return res.status(400).json({error:'Payment is not confirmed as captured. If money was deducted, contact support with your payment reference.'});
    const update=await fetch(`${url}/rest/v1/digital_orders?razorpay_order_id=eq.${encodeURIComponent(orderId)}`,{method:'PATCH',headers:{...headers,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify({payment_status:'paid',razorpay_payment_id:paymentId,paid_at:new Date().toISOString()})});
    if(!update.ok)return res.status(503).json({error:'Payment was verified but order updating failed. Contact support with the payment reference.'});
    const productRes=await fetch(`${url}/rest/v1/digital_products?id=eq.${encodeURIComponent(order.product_id)}&select=storage_path,status`,{headers}); const productRows=await productRes.json(); const product=productRows?.[0]; const path=product?.storage_path; if(!productRes.ok||!path)return res.status(400).json({error:'Product delivery is not configured.'});
    const signed=await fetch(`${url}/storage/v1/object/sign/digital-products/${encodeURIComponent(path).replace(/%2F/g,'/')}`,{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({expiresIn:600})});
    const signedData=await signed.json();
    if(!signed.ok||!signedData.signedURL)return res.status(503).json({error:'Payment is verified, but the download is not ready. Contact support with your payment reference.'});
    const downloadUrl=signedData.signedURL.startsWith('http')?signedData.signedURL:`${url}/storage/v1${signedData.signedURL}`;
    return res.status(200).json({verified:true,downloadUrl,email:order.customer_email});
  }catch(e){console.error('verify-payment failed');return res.status(500).json({error:'Could not complete payment verification. Contact support if money was deducted.'});}
};
