module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { RAZORPAY_KEY_ID:keyId, RAZORPAY_KEY_SECRET:secret, SUPABASE_URL:supabaseUrl, SUPABASE_SERVICE_ROLE_KEY:serviceKey } = process.env;
  if (!keyId || !secret || !supabaseUrl || !serviceKey) return res.status(503).json({ error: 'Payments are not configured yet.' });
  const { productId, email } = req.body || {};
  if (!/^[a-z0-9-]{3,120}$/.test(String(productId || ''))) return res.status(400).json({ error: 'Product is not available.' });
  const customerEmail = String(email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail) || customerEmail.length > 254) return res.status(400).json({ error: 'Enter a valid email address.' });
  try {
    const pr = await fetch(`${supabaseUrl}/rest/v1/digital_products?id=eq.${encodeURIComponent(productId)}&status=eq.published&select=id,name,price,currency,storage_path`, {headers:{apikey:serviceKey,Authorization:`Bearer ${serviceKey}`}});
    const products = await pr.json(); const product = products?.[0];
    if (!pr.ok || !product || !Number.isInteger(Number(product.price)) || Number(product.price) < 1 || !product.storage_path) return res.status(400).json({error:'Product is not currently available for purchase.'});
    const rr = await fetch('https://api.razorpay.com/v1/orders', { method:'POST', headers:{'Authorization':'Basic '+Buffer.from(keyId+':'+secret).toString('base64'),'Content-Type':'application/json'}, body:JSON.stringify({amount:Number(product.price)*100,currency:'INR',receipt:'mrmr_'+Date.now().toString(36),notes:{product_id:productId,customer_email:customerEmail}}) });
    const order = await rr.json();
    if (!rr.ok) return res.status(502).json({error:'Could not create a payment order. Please try again.'});
    const db = await fetch(`${supabaseUrl}/rest/v1/digital_orders`, {method:'POST',headers:{apikey:serviceKey,Authorization:`Bearer ${serviceKey}`,'Content-Type':'application/json',Prefer:'return=minimal'},body:JSON.stringify({product_id:productId,customer_email:customerEmail,amount_paise:Number(product.price)*100,currency:'INR',razorpay_order_id:order.id,payment_status:'created'})});
    if (!db.ok) { await fetch(`https://api.razorpay.com/v1/orders/${order.id}`, {method:'PATCH',headers:{'Authorization':'Basic '+Buffer.from(keyId+':'+secret).toString('base64'),'Content-Type':'application/json'},body:JSON.stringify({notes:{cancelled:'database_record_failed'}})}).catch(()=>{}); return res.status(503).json({error:'Order records are not ready. Please try again later.'}); }
    return res.status(200).json({orderId:order.id,amount:order.amount,currency:order.currency,keyId,productName:product.name,email:customerEmail});
  } catch(e) { console.error('create-order failed'); return res.status(500).json({error:'Unable to start checkout right now.'}); }
};
