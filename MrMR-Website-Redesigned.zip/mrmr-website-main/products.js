(async function(){
 const grid=document.getElementById('productGrid'); const status=document.getElementById('storeStatus'); if(!grid)return;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let products=[];
 try{
  const response=await fetch('products.json',{cache:'no-store'}); if(!response.ok)throw new Error('catalog'); products=await response.json();
  if(window.MR_SUPABASE_CONFIG && window.supabase?.createClient){
   const sb=window.supabase.createClient(window.MR_SUPABASE_CONFIG.url,window.MR_SUPABASE_CONFIG.publishableKey);
   const {data,error}=await sb.from('digital_products').select('id,slug,name,price,currency,category,summary,description,deliverables,format,status,featured,storage_path').eq('status','published').order('sort_order');
   if(!error && Array.isArray(data)) products=data;
  }
 }catch(e){status.textContent='Showing the local catalogue. Live catalogue sync will be available after database setup.'; try{products=await (await fetch('products.json')).json()}catch(_){}}
 products=products.filter(p=>p.status==='published');
 if(!products.length){grid.innerHTML='<p>Products are being prepared. Please check back soon.</p>';return}
 grid.innerHTML=products.map((p,i)=>`<article class="product-card"><div class="product-type">${esc(p.category||'Digital resource')}</div><h2>${esc(p.name)}</h2><p>${esc(p.summary||p.description||'Practical digital resource from Mr.MR.')}</p><ul>${(p.deliverables||[]).slice(0,4).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><div class="format">${esc(p.format||'Digital download')}</div><div class="price">₹${Number(p.price).toLocaleString('en-IN')}</div><button class="btn primary buy" data-product="${esc(p.id)}">Buy now <b>↗</b></button></article>`).join('');
 grid.addEventListener('click',e=>{const b=e.target.closest('[data-product]');if(!b)return;const p=products.find(x=>x.id===b.dataset.product);if(p)location.href='checkout.html?product='+encodeURIComponent(p.id)});
})();
