-- Mr.MR Digital Products catalog and order records
-- Run in Supabase SQL Editor after reviewing. Keep digital-products Storage bucket PRIVATE.
create table if not exists public.digital_products (
  id text primary key,
  slug text not null unique,
  name text not null,
  price integer not null check (price >= 0), -- INR whole rupees
  currency text not null default 'INR' check (currency = 'INR'),
  category text not null default 'Digital resource',
  summary text not null,
  description text not null default '',
  deliverables jsonb not null default '[]'::jsonb,
  format text not null default 'Digital download',
  status text not null default 'draft' check (status in ('draft','published','archived')),
  featured boolean not null default false,
  storage_path text not null,
  sort_order integer not null default 100,
  updated_at timestamptz not null default now()
);
create table if not exists public.digital_orders (
  id uuid primary key default gen_random_uuid(),
  product_id text not null references public.digital_products(id),
  customer_email text not null,
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR',
  razorpay_order_id text unique,
  razorpay_payment_id text unique,
  payment_status text not null default 'created' check (payment_status in ('created','paid','failed','refunded')),
  created_at timestamptz not null default now(),
  paid_at timestamptz
);
alter table public.digital_products enable row level security;
alter table public.digital_orders enable row level security;
drop policy if exists "Published products are public" on public.digital_products;
create policy "Published products are public" on public.digital_products for select using (status = 'published');
drop policy if exists "Admins manage products" on public.digital_products;
create policy "Admins manage products" on public.digital_products for all to authenticated using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin') with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
-- Orders are service-role only; no public or authenticated client policies are created.
revoke all on public.digital_orders from anon, authenticated;
grant select on public.digital_products to anon, authenticated;
grant insert, update, delete on public.digital_products to authenticated;
-- Create a PRIVATE Storage bucket named digital-products in the Supabase dashboard.
-- Upload only finished product files with exact storage_path names from products.json.
-- Never place paid files in a publicly served website folder.

-- Seed the initial catalogue. Prices/statuses can subsequently be edited in product-admin.html.
insert into public.digital_products (id,slug,name,price,currency,category,summary,description,deliverables,format,status,featured,storage_path,sort_order) values
('student-freelancer-starter-kit','student-freelancer-starter-kit','Student Freelancer Starter Kit',79,'INR','Getting started','Choose one realistic service, build proof, and plan your first week.','A practical editable guide for students who want to explore online work without false income promises.','["Skill-to-service worksheet","Offer definition template","Proof-sample checklist","7-day starter plan"]'::jsonb,'Editable Word document (.docx)','published',true,'01-Student-Freelancer-Starter-Kit.docx',10),
('freelance-offer-pricing-toolkit','freelance-offer-pricing-toolkit','Freelance Offer & Pricing Toolkit',149,'INR','Templates & workflows','Define deliverables, boundaries, estimates, quotes, and change requests.','Reusable templates to scope a small freelance service clearly and communicate what is included.','["Offer canvas","Scope checklist","Estimate worksheet","Quote template","Change-request template"]'::jsonb,'Editable Word document (.docx)','published',true,'02-Freelance-Offer-Pricing-Toolkit.docx',20),
('freelance-income-expense-tracker','freelance-income-expense-tracker','Freelance Income & Expense Tracker',149,'INR','Trackers & planners','Record income, expenses, hours, payment status, and monthly totals.','An editable spreadsheet for keeping a simple record of freelance activity. Net figures are before tax and other obligations.','["Income log with filters","Monthly totals","Net before tax calculation","Income-per-hour calculation"]'::jsonb,'Excel workbook (.xlsx)','published',true,'03-Freelance-Income-Expense-Tracker.xlsx',30),
('online-work-scam-safety-guide','online-work-scam-safety-guide','Online Work Scam-Safety Guide',49,'INR','Safety & basics','A practical red-flag and account-safety checklist for online work.','A concise PDF to help students pause, verify opportunities, and protect accounts and personal information.','["Opportunity red flags","Before-you-proceed checklist","What to do if something feels wrong","Decision checklist"]'::jsonb,'PDF document (.pdf)','draft',false,'04-Online-Work-Scam-Safety-Guide.pdf',40)
on conflict (id) do nothing;
